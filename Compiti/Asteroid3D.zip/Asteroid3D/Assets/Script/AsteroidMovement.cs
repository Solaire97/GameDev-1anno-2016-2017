﻿using UnityEngine;
using System.Collections;

public class AsteroidMovement : MonoBehaviour {
    public float speed;
    public float timeToDestoy;
    private bool isColliding = false;

	// Use this for initialization
	void Start ()
    {
        //Generazione Random della direzione dell'asteroide
        Vector3 randomDirection = new Vector3(Random.Range(-359, 359), Random.Range(-359, 359), Random.Range(-359, 359));
        transform.Rotate(randomDirection);
        Destroy(gameObject, timeToDestoy);//Destroy dell'oggetto nel tempo indicato
	}
	
	// Update is called once per frame
	void Update ()
    {
        //movimento dell'asteroide
        transform.position += transform.forward * speed * Time.deltaTime;
        //Distruzione dell'asteroide se collide
        if(isColliding == true)
        { 
            Destroy(gameObject);
        }
	}

    private void OnCollisionEnter(Collision other)
    {
        //Controllo del tag dell'oggetto che collide
        if(other.gameObject.CompareTag("Bullet"))
        {
            //Debug.Log("Colpito");
            Destroy(other.gameObject);//distruzione dell'oggetto che ha colliso
            isColliding = true;
        }
    }
}


