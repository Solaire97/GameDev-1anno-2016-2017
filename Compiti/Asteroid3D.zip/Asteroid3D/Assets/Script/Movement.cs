﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {

    public float speed;
    public float rotationSpeed;
    private float realspeed;

	// Use this for initialization
	void Start ()
    {
        realspeed = speed;
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Input per la rotazione del player
        transform.Translate(Vector3.forward * Time.deltaTime * realspeed);
	    if(Input.GetKey(KeyCode.UpArrow))
        {
            transform.Rotate(Vector3.left, Time.deltaTime * rotationSpeed);
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            transform.Rotate(Vector3.right, Time.deltaTime * rotationSpeed);
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.Rotate(Vector3.up, Time.deltaTime * rotationSpeed);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Rotate(Vector3.down, Time.deltaTime * rotationSpeed);
        }
        //accellerazione
        if(Input.GetKeyDown(KeyCode.W))
        {
            realspeed += 5;
        }
        //Decelerrazione
        if(Input.GetKeyDown(KeyCode.S))
        {
            realspeed -= 2;
        }
        //Ritorno alla velocità normale
        if(Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.S))
        {
            realspeed = speed;
        }
        Quaternion q = transform.rotation;
        q.eulerAngles = new Vector3(q.eulerAngles.x, q.eulerAngles.y, 0);
        transform.rotation = q;

    }
}
