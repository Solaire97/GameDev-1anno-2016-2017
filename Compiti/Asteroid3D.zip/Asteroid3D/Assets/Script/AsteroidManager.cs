﻿using UnityEngine;
using System.Collections;

public class AsteroidManager : MonoBehaviour
{
    public GameObject player;
    public GameObject Asteroid;
    public int spawnRange;
    public bool spawn;
    public float spawntime;

    void Start()
    {
        //Inizio Coroutine per lo spawn di asteroidi
        StartCoroutine("CreateAsteroid");
    }

    IEnumerator CreateAsteroid()
    {
        while(spawn)
        {
            //Instanzio un oggetto Asteroid in una sfera che ha come centro la posizione del player
            Instantiate(Asteroid, (Random.insideUnitSphere * spawnRange) + player.transform.position, Quaternion.identity);
            yield return new WaitForSeconds(spawntime);//Tempo che passa (in secondi) prima dello spawn di un'altro oggetto Asteroid
            yield return null;
        }
        yield return null;  
    }
}
