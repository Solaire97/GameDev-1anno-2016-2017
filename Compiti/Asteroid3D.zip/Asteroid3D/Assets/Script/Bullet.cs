﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour
{
    public float timeToDestroy;

	// Use this for initialization
	void Start ()
    {
        Destroy(gameObject, timeToDestroy);//Distruzione dell'oggetto nel tempo indicato
    }
}
