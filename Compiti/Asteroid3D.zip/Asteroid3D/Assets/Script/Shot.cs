﻿using UnityEngine;
using System.Collections;

public class Shot : MonoBehaviour {

    public GameObject bullet;
    public float fireRate;
    public float shotForce;
    private float timer;
    private bool shooting = false;
    private Quaternion bulletRotation = new Quaternion(0.7f, 0, 0, 0.7f);

    void Shoot()
    {
        //Instazio l'oggetto bullet davanti al player con la direzione del player
        GameObject instance = (GameObject)Instantiate(bullet, transform.position, transform.rotation * bulletRotation);
        instance.GetComponent<Rigidbody>().velocity = this.transform.TransformDirection(Vector3.forward * shotForce);//aggiunta forza all'oggetto instanzioato

    }

    void Update()
    {
        //Fire Rate
        timer += Time.deltaTime;
        if (timer > fireRate && Input.GetKey(KeyCode.Space))
        {
            Shoot();
            timer = 0; // reset time per il fire rate
        }
    }
}
